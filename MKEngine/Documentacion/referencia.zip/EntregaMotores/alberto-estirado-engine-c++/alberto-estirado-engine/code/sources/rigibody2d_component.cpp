/**
*
* @author Alberto Estirado L�pez
*
* Distributed under the Boost Software License, version  1.0
* See documents/LICENSE.TXT or www.boost.org/LICENSE_1_0.txt
*
* @date 26/01/2022
*
* estiradoalberto@gmail.com
*/


#include <rigibody2d_component.hpp>
#include <entity.hpp>
#include <transform.hpp>
#include <physics2d_system.hpp>

namespace engine {

	

}